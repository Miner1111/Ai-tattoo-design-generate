import { config } from 'dotenv';
config();

import '@/ai/flows/generate-tattoo-design.ts';
import '@/ai/flows/simulate-tattoo-placement.ts';